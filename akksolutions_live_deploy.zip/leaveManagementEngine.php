<?php
/* =====================================================================
   AKK Leave System - Leave Validation Engine (GENERIC / SELLABLE)
   ---------------------------------------------------------------------
   MEKA pera thibune #1..#12 hardcoded ID rules ekata bind wela. Eka
   AKK SOLUTIONS internal staff ekata witharai valid wuna. ALUT client
   kenekuta me system eka denna kotasa me engine eka GENERIC widiyata
   wada karanawa:

     1. Monthly Leave Quota     -> app_settings eken (default 4)
     2. Shift Minimum Staffing  -> users table eke ACTUAL staff gen
        (Morning / Evening minima settings eken, default 5 / 3)
     3. Conflict / Dependency Rules -> OPTIONAL. app_settings eke
        'use_dependency_rules' = 1 nam witharak #1..#12 legacy rules
        apply wenawa (parana AKK deployment ekata). Generic client
        ekata meka 0 se thiyanna (default).

   Settings admin panel ke meka venas karanna puluwan: RUN here
   (admin.php > Security & Settings). Eka nathuwa db.php wala
   defaults thiyenawa.
   ===================================================================== */

class LeaveManagementEngine {
    private $pdo;

    public function __construct($pdoInstance) {
        $this->pdo = $pdoInstance;
    }

    /* ---- Configuration (app_settings, fallen back to defaults) ---- */
    public function getMaxMonthlyLeaves(): int {
        return (int)$this->getSetting('max_monthly_leaves', 4);
    }

    public function getMinMorningStaff(): int {
        return (int)$this->getSetting('min_morning_staff', 5);
    }

    public function getMinEveningStaff(): int {
        return (int)$this->getSetting('min_evening_staff', 3);
    }

    public function usesDependencyRules(): bool {
        return (int)$this->getSetting('use_dependency_rules', 0) === 1;
    }

    private function getSetting(string $key, $default) {
        try {
            $stmt = $this->pdo->prepare("SELECT setting_value FROM app_settings WHERE setting_key = :k");
            $stmt->execute([':k' => $key]);
            $v = $stmt->fetchColumn();
            return ($v === false || $v === null || $v === '') ? $default : $v;
        } catch (PDOException $e) {
            return $default;
        }
    }

    /* ---- Not-null replacement so comparisons on '' are safe ---- */
    private function isOnLeaveToday(array $onLeaveToday, int $empId): bool {
        return in_array($empId, $onLeaveToday, true);
    }

    /**
     * Main entry point. Returns:
     *   ['status' => 'APPROVED'|'REJECTED', 'reason' => '...', 'is_emergency' => bool]
     */
    public function validateLeaveRequest(int $empId, string $leaveDate, string $appliedShift, bool $isEmergency = false): array {
        $maxMonthly = $this->getMaxMonthlyLeaves();

        // 1. Monthly quota
        $monthlyCount = $this->getApprovedCountForMonth($empId, $leaveDate);
        if ($maxMonthly > 0 && $monthlyCount >= $maxMonthly) {
            return $this->reject("මසකට ලබාගත හැකි උපරිම නිවාඩු සීමාව ({$maxMonthly}) ඉක්මවා ඇත.");
        }

        // 2. Already approved this date?
        $onLeaveToday = $this->getApprovedUserIdsByDate($leaveDate);
        if ($this->isOnLeaveToday($onLeaveToday, $empId)) {
            return $this->reject('ඔබ දැනටමත් මෙම දිනය සඳහා නිවාඩුවක් ලබාගෙන ඇත.');
        }

        $simulated = array_merge($onLeaveToday, [$empId]);

        // 3. Optional legacy dependency rules (#1..#12) - generic clients turn OFF
        if ($this->usesDependencyRules()) {
            $dep = $this->checkDependencyRules($simulated, $onLeaveToday, $empId);
            if (!$dep['valid']) {
                return $this->reject($dep['reason']);
            }
        }

        // 4. Generic shift minimum staffing (computed from ACTUAL staff)
        $shiftResult = $this->checkShiftMinimums($simulated, $empId, $appliedShift);
        if (!$shiftResult['valid']) {
            return $this->reject($shiftResult['reason']);
        }

        return $this->approve();
    }

    /* -----------------------------------------------------------------
       SHIFT MINIMUM STAFF (GENERIC)
       Morning staff  = users with shift_type M or BOTH
       Evening staff  = users with shift_type E or BOTH
       Minimums are configurable via app_settings.
       ----------------------------------------------------------------- */
    private function checkShiftMinimums(array $simulated, int $empId, string $appliedShift): array {
        $minM = $this->getMinMorningStaff();
        $minE = $this->getMinEveningStaff();

        $morningMemberIds = $this->getShiftMemberIds(['M', 'BOTH']);
        $eveningMemberIds = $this->getShiftMemberIds(['E', 'BOTH']);

        $morningLeaves  = count(array_intersect($morningMemberIds, $simulated));
        $eveningLeaves  = count(array_intersect($eveningMemberIds, $simulated));

        $totalMorning = count($morningMemberIds);
        $totalEvening = count($eveningMemberIds);

        $workingMorning = $totalMorning - $morningLeaves;
        $workingEvening = $totalEvening - $eveningLeaves;

        $reasons = [];
        if ($minM > 0 && $workingMorning < $minM) {
            $reasons[] = "Morning Shift එකේ අවම සේවක සංඛ්‍යාව ({$minM}) පවත්වා ගත නොහැක.";
        }
        if ($minE > 0 && $workingEvening < $minE) {
            $reasons[] = "Evening Shift එකේ අවම සේවක සංඛ්‍යාව ({$minE}) පවත්වා ගත නොහැක.";
        }
        if (!empty($reasons)) {
            return ['valid' => false, 'reason' => implode(' ', $reasons)];
        }
        return ['valid' => true];
    }

    /* -----------------------------------------------------------------
       LEGACY DEPENDENCY RULES (#1..#12) - OPTIONAL (AKK internal only)
       ----------------------------------------------------------------- */
    private function checkDependencyRules(array $simulated, array $onLeaveToday, int $empId): array {
        // Group A (#1, #2, #3) mutual lock
        $groupA = array_intersect([1, 2, 3], $simulated);
        if (count($groupA) > 1) {
            return ['valid' => false, 'reason' => '#1, #2, සහ #3 අතරින් එකවර දෙදෙනෙකුට නිවාඩු ගත නොහැක (Mutual Exclusion).'];
        }

        // #4 blocks if any of #1,#2,#3 leaves
        if ($empId === 4 && array_intersect([1, 2, 3], $onLeaveToday)) {
            return ['valid' => false, 'reason' => '#1, #2, හෝ #3 සේවකයෙකු නිවාඩු ගෙන ඇති බැවින් #4 හට නිවාඩු ලබාගත නොහැක.'];
        }

        // #7 & #8 mutual exclusion
        if (in_array(7, $simulated) && in_array(8, $simulated)) {
            return ['valid' => false, 'reason' => '#7 සහ #8 යන දෙදෙනාටම එකවර නිවාඩු ලබාගත නොහැක.'];
        }

        // #10 evening critical lock
        if (in_array(10, $onLeaveToday) && in_array($empId, [9, 11, 12])) {
            return ['valid' => false, 'reason' => '#10 සේවකයා නිවාඩු ගෙන ඇති බැවින් Evening Shift එක සම්පූර්ණයෙන්ම Lock වී ඇත.'];
        }

        // #9 rules
        if (in_array(9, $simulated)) {
            if (in_array(4, $simulated) || in_array(10, $simulated)) {
                return ['valid' => false, 'reason' => '#9 නිවාඩු ගන්නා විට #4 සහ #10 ට නිවාඩු ගත නොහැක.'];
            }
            $allowedFor9 = array_intersect([11, 12], $simulated);
            if (count($allowedFor9) > 1) {
                return ['valid' => false, 'reason' => '#9 නිවාඩු ගන්නා විට #11 සහ #12 අතරින් ලබාගත හැක්කේ එක් අයෙකුට පමණි.'];
            }
        }

        // #11 rules
        if (in_array(11, $simulated)) {
            if (in_array(9, $simulated) || in_array(10, $simulated)) {
                return ['valid' => false, 'reason' => '#11 නිවාඩු ගන්නා විට #9 සහ #10 ට නිවාඩු ගත නොහැක.'];
            }
            $allowedFor11 = array_intersect([12, 4], $simulated);
            if (count($allowedFor11) > 1) {
                return ['valid' => false, 'reason' => '#11 නිවාඩු ගන්නා විට #12 සහ #4 අතරින් ලබාගත හැක්කේ එක් අයෙකුට පමණි.'];
            }
        }

        // #12 rules
        if (in_array(12, $simulated)) {
            $allowedFor12 = array_intersect([9, 10, 11, 4], $simulated);
            if (count($allowedFor12) > 1) {
                return ['valid' => false, 'reason' => '#12 නිවාඩු ගන්නා විට #9, #10, #11 සහ #4 අතරින් ලබාගත හැක්කේ එක් අයෙකුට පමණි.'];
            }
        }

        return ['valid' => true];
    }

    /* -----------------------------------------------------------------
       HELPERS
       ----------------------------------------------------------------- */
    private function getApprovedCountForMonth(int $empId, string $date): int {
        $month = date('Y-m', strtotime($date));
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM leave_requests
                                     WHERE user_id = :uid AND SUBSTR(leave_date,1,7) = :m AND status = 'Approved'");
        $stmt->execute([':uid' => $empId, ':m' => $month]);
        return (int)$stmt->fetchColumn();
    }

    private function getApprovedUserIdsByDate(string $date): array {
        $stmt = $this->pdo->prepare("SELECT user_id FROM leave_requests WHERE leave_date = :d AND status = 'Approved'");
        $stmt->execute([':d' => $date]);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    private function getShiftMemberIds(array $shifts): array {
        $in = implode(',', array_fill(0, count($shifts), '?'));
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE shift_type IN ($in)");
        $stmt->execute($shifts);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    private function approve(): array {
        return ['status' => 'APPROVED', 'reason' => 'සියලුම Business Rules සහ Shift Limits සම්පූර්ණ විය. නිවාඩුව ස්වයංක්‍රීයව අනුමත විය.'];
    }

    private function reject(string $reason): array {
        return ['status' => 'REJECTED', 'reason' => $reason];
    }
}
