<?php
/* =====================================================================
   AKK Leave System - Create Account (gate-free, ONE TIME setup)
   ---------------------------------------------------------------------
   Web (InfinityFree) eken Create Account eken obata ona lakunu eka
   hoje: this page eka admin key eka dala account ekak hadanna puluwan
   (admin username/password gate EKA NA - key ekak witharai).

   Ht Traded: setup_account_AKK.php ekata paththuwa.
   WADA: Upload karala eka open karanna:
       https://akksolutions.wuaze.com/create_account.php
   Tamatama oyage site eka hariyatama thiyenoth.
   ===================================================================== */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/logger.php';

$codes = getAccessCodes($conn);
$adminKey = $codes['admin_key'];

$error = '';
$success = '';

if (isset($_POST['create'])) {
    $name     = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $shift    = $_POST['shift'] ?? '';
    $position = trim($_POST['position'] ?? '');
    $role     = ($_POST['role'] ?? 'employee') === 'admin' ? 'admin' : 'employee';
    $key      = trim($_POST['admin_key'] ?? '');

    if ($name === '' || $username === '' || $password === '') {
        $error = 'Name, Username saha Password okkoma anivaryayi.';
    } elseif (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        $error = 'Name eka akuru 2-100 athara venna one.';
    } elseif (!preg_match('/^[a-zA-Z0-9._]{3,50}$/', $username)) {
        $error = 'Username akuru 3-50 (a-z, 0-9, . _) witharak venna one.';
    } elseif (strlen($password) < 4 || strlen($password) > 72) {
        $error = 'Password eka akuru 4-72 athara venna one.';
    } elseif ($role === 'employee' && !in_array($shift, ['M', 'E', 'BOTH'], true)) {
        $error = 'Shift eka M / E / BOTH witharak venna one.';
    } elseif ($role === 'employee' && $position === '') {
        $error = 'Position eka danna (ud ah: Manager, Supervisor, Operator).';
    } elseif (mb_strlen($position) > 100) {
        $error = 'Position eka akuru 100 n ithi witharak venna one.';
    } elseif ($role === 'admin' && !hash_equals((string)$adminKey, (string)$key)) {
        writeLog('CREATE_FAILED', 'Invalid admin key for: ' . $username);
        $error = 'Admin Key eka veradi.';
    } else {
        $exists = 0;
        foreach (['admin_users', 'users'] as $tbl) {
            $s = $conn->prepare("SELECT COUNT(*) FROM $tbl WHERE username = :u");
            $s->execute([':u' => $username]);
            $exists += (int)$s->fetchColumn();
        }
        if ($exists > 0) {
            $error = 'Me username eka danata use karana. Vena ekak danna.';
        } else {
            if ($role === 'admin') {
                $stmt = $conn->prepare("INSERT INTO admin_users (name, email, password, username, position) VALUES (:n, :e, :p, :u, :pos)");
                $stmt->execute([':n' => $name, ':e' => null, ':p' => password_hash($password, PASSWORD_DEFAULT), ':u' => $username, ':pos' => $position]);
                writeLog('ACCOUNT_CREATED', 'ADMIN account created via create_account: ' . $username);
                $success = 'Admin account eka sampurnayenma saduni! Dan login.php eken Sign In karanna.';
            } else {
                $stmt = $conn->prepare("INSERT INTO users (name, email, password, username, shift_type, position) VALUES (:n, :e, :p, :u, :s, :pos)");
                $stmt->execute([':n' => $name, ':e' => null, ':p' => password_hash($password, PASSWORD_DEFAULT), ':u' => $username, ':s' => $shift, ':pos' => $position]);
                writeLog('ACCOUNT_CREATED', 'Employee account created via create_account: ' . $username . ' (' . $shift . ')');
                $success = 'Employee account eka sampurnayenma saduni! Dan login.php eken Sign In karanna.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AKK Solutions | Create Account</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    * { font-family: 'Inter', system-ui, sans-serif; }
</style>
</head>
<body class="bg-slate-950 min-h-screen flex items-center justify-center p-4">
<div class="w-full max-w-md bg-slate-900/70 border border-slate-700/70 rounded-3xl p-8 shadow-2xl space-y-5">
    <div class="text-center">
        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 mx-auto flex items-center justify-center shadow-lg shadow-indigo-500/30 mb-3">
            <span class="text-xl font-black text-white">AK</span>
        </div>
        <h1 class="text-2xl font-extrabold text-white">Create Account</h1>
        <p class="text-slate-400 text-xs mt-1">Alut account ekak hadaganna (admin key ekak one)</p>
    </div>

    <?php if ($error): ?>
    <div class="p-3 rounded-xl bg-rose-500/10 border border-rose-500/25 text-xs text-rose-300 font-medium"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-300 font-medium"><?= htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Account Type</label>
            <select name="role" onchange="document.getElementById('shiftWrap').style.display = this.value==='employee'?'':'none'; document.getElementById('keyWrap').style.display = this.value==='admin'?'':'none';"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 transition-all [&>option]:bg-slate-900">
                <option value="employee">Employee Account</option>
                <option value="admin">Admin Account</option>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Full Name</label>
            <input type="text" name="name" required placeholder="Enter your full name"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all">
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Username</label>
            <input type="text" name="username" required placeholder="Choose a username"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all">
        </div>
        <div id="shiftWrap">
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Shift</label>
            <select name="shift" class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 transition-all [&>option]:bg-slate-900">
                <option value="">-- Select Shift --</option>
                <option value="M">Morning Shift</option>
                <option value="E">Evening Shift</option>
                <option value="BOTH">Both Shifts</option>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Position</label>
            <input type="text" name="position" placeholder="Job position eka danna (ud ah: Manager, Supervisor, Operator)"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all">
        </div>
        <div id="keyWrap" style="display:none">
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Admin Key</label>
            <input type="password" name="admin_key" placeholder="Company admin key eka danna"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all">
        </div>
        <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Password</label>
            <input type="password" name="password" required placeholder="Choose a password (min 4 characters)"
                class="w-full bg-slate-800/70 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all">
        </div>
        <button type="submit" name="create"
            class="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 text-sm">
            Create Account
        </button>
    </form>
    <p class="text-center text-[11px] text-slate-500 mt-2">
        Dan account eka hamba wage one nam <a href="login.php" class="text-indigo-400 hover:text-indigo-300 font-semibold">Sign In</a>
    </p>
</div>
</body>
</html>